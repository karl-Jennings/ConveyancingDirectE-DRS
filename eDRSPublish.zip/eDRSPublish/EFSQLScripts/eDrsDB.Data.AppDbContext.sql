﻿IF OBJECT_ID(N'[__EFMigrationsHistory]') IS NULL
BEGIN
    CREATE TABLE [__EFMigrationsHistory] (
        [MigrationId] nvarchar(150) NOT NULL,
        [ProductVersion] nvarchar(32) NOT NULL,
        CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY ([MigrationId])
    );
END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210121043604_init')
BEGIN
    CREATE TABLE [RegistrationTypes] (
        [RegistrationTypeId] bigint NOT NULL IDENTITY,
        [TypeName] nvarchar(150) NULL,
        [TypeCode] nvarchar(150) NULL,
        [Url] nvarchar(300) NULL,
        [UpdatedDate] datetime2 NOT NULL,
        [Status] bit NOT NULL DEFAULT CAST(1 AS bit),
        CONSTRAINT [PK_RegistrationTypes] PRIMARY KEY ([RegistrationTypeId])
    );
END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210121043604_init')
BEGIN
    CREATE TABLE [Users] (
        [UserId] bigint NOT NULL IDENTITY,
        [Firstname] nvarchar(150) NOT NULL,
        [Lastname] nvarchar(150) NULL,
        [Email] nvarchar(350) NULL,
        [Designation] nvarchar(max) NOT NULL,
        [PasswordHash] varbinary(max) NULL,
        [PasswordSalt] varbinary(max) NULL,
        [CreatedDate] datetime2 NOT NULL DEFAULT (GETDATE()),
        [UpdatedDate] datetime2 NOT NULL,
        [Status] bit NOT NULL DEFAULT CAST(1 AS bit),
        CONSTRAINT [PK_Users] PRIMARY KEY ([UserId])
    );
END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210121043604_init')
BEGIN
    CREATE TABLE [DocumentReferences] (
        [DocumentReferenceId] bigint NOT NULL IDENTITY,
        [ReferenceName] nvarchar(150) NULL,
        [ReferenceCode] nvarchar(150) NULL,
        [CreatedDate] datetime2 NOT NULL DEFAULT (GETDATE()),
        [UpdatedDate] datetime2 NOT NULL,
        [Email] nvarchar(350) NULL,
        [Notes] nvarchar(max) NULL,
        [Status] bit NOT NULL DEFAULT CAST(1 AS bit),
        [UserId] bigint NOT NULL,
        [RegistrationTypeId] bigint NOT NULL,
        CONSTRAINT [PK_DocumentReferences] PRIMARY KEY ([DocumentReferenceId]),
        CONSTRAINT [FK_DocumentReferences_RegistrationTypes_RegistrationTypeId] FOREIGN KEY ([RegistrationTypeId]) REFERENCES [RegistrationTypes] ([RegistrationTypeId]) ON DELETE CASCADE,
        CONSTRAINT [FK_DocumentReferences_Users_UserId] FOREIGN KEY ([UserId]) REFERENCES [Users] ([UserId]) ON DELETE CASCADE
    );
END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210121043604_init')
BEGIN
    CREATE TABLE [TitleNumbers] (
        [TitleNumberId] bigint NOT NULL IDENTITY,
        [TitleNumberCode] nvarchar(150) NULL,
        [PropertyName] nvarchar(500) NULL,
        [CreatedDate] datetime2 NOT NULL DEFAULT (GETDATE()),
        [UpdatedDate] datetime2 NOT NULL,
        [Status] bit NOT NULL DEFAULT CAST(1 AS bit),
        [DocumentReferenceId] bigint NOT NULL,
        CONSTRAINT [PK_TitleNumbers] PRIMARY KEY ([TitleNumberId]),
        CONSTRAINT [FK_TitleNumbers_DocumentReferences_DocumentReferenceId] FOREIGN KEY ([DocumentReferenceId]) REFERENCES [DocumentReferences] ([DocumentReferenceId]) ON DELETE CASCADE
    );
END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210121043604_init')
BEGIN
    CREATE TABLE [ApplicationForms] (
        [ApplicationFormId] bigint NOT NULL IDENTITY,
        [Type] nvarchar(300) NULL,
        [Reference] nvarchar(300) NULL,
        [ChargeDate] datetime2 NOT NULL,
        [IsAgreed] bit NOT NULL,
        [FileLocation] nvarchar(max) NULL,
        [CertificationType] nvarchar(max) NULL,
        [Fee] decimal(18,2) NOT NULL,
        [CreatedDate] datetime2 NOT NULL DEFAULT (GETDATE()),
        [UpdatedDate] datetime2 NOT NULL,
        [Status] bit NOT NULL DEFAULT CAST(1 AS bit),
        [TitleNumberId] bigint NOT NULL,
        CONSTRAINT [PK_ApplicationForms] PRIMARY KEY ([ApplicationFormId]),
        CONSTRAINT [FK_ApplicationForms_TitleNumbers_TitleNumberId] FOREIGN KEY ([TitleNumberId]) REFERENCES [TitleNumbers] ([TitleNumberId]) ON DELETE CASCADE
    );
END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210121043604_init')
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'RegistrationTypeId', N'Status', N'TypeCode', N'TypeName', N'UpdatedDate', N'Url') AND [object_id] = OBJECT_ID(N'[RegistrationTypes]'))
        SET IDENTITY_INSERT [RegistrationTypes] ON;
    INSERT INTO [RegistrationTypes] ([RegistrationTypeId], [Status], [TypeCode], [TypeName], [UpdatedDate], [Url])
    VALUES (CAST(1 AS bigint), CAST(1 AS bit), N'doc_reg', N'Document Registration', '2021-01-21T10:06:04.2671005+05:30', N'document-registration'),
    (CAST(2 AS bigint), CAST(1 AS bit), N'lease_ext', N'Lease Extension', '2021-01-21T10:06:04.2679142+05:30', N'lease-extension'),
    (CAST(3 AS bigint), CAST(1 AS bit), N'new_lease', N'New Lease', '2021-01-21T10:06:04.2679169+05:30', N'new-lease'),
    (CAST(4 AS bigint), CAST(1 AS bit), N'transfer', N'Transfer of Part', '2021-01-21T10:06:04.2679171+05:30', N'transfer'),
    (CAST(5 AS bigint), CAST(1 AS bit), N'rem_frm', N'Removal of default form A restriction (JP1)', '2021-01-21T10:06:04.2679173+05:30', N'removal-form');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'RegistrationTypeId', N'Status', N'TypeCode', N'TypeName', N'UpdatedDate', N'Url') AND [object_id] = OBJECT_ID(N'[RegistrationTypes]'))
        SET IDENTITY_INSERT [RegistrationTypes] OFF;
END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210121043604_init')
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'UserId', N'Designation', N'Email', N'Firstname', N'Lastname', N'PasswordHash', N'PasswordSalt', N'Status', N'UpdatedDate') AND [object_id] = OBJECT_ID(N'[Users]'))
        SET IDENTITY_INSERT [Users] ON;
    INSERT INTO [Users] ([UserId], [Designation], [Email], [Firstname], [Lastname], [PasswordHash], [PasswordSalt], [Status], [UpdatedDate])
    VALUES (CAST(1 AS bigint), N'admin', N'dushyanthaccura@gmail.com', N'Admin', NULL, 0x61990A9E3BC4CC829386E75E09BBA6C7CFC05E4B3101472402226FB64F383D72679DB9512E9AD4F46CC3DEE256D153B14CFDAE1125B656296AE503001D9611AB, 0x0B954465215E1B3A03CAC2C233C8EC265CD71E8E0F83DB57F503F50321058056A458535B2294504E68A4B50099B5345D241F9892AEDC0177688F5B20C5A20EDBB5864F3DA4AD40EDA0F38524ED79A894632EA29F8798ADD5E138267E7CD81994387A17D048261E876D2FB1E90C359AED64A57BCCC63B114BDE98D911456A4FEC, CAST(1 AS bit), '0001-01-01T00:00:00.0000000');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'UserId', N'Designation', N'Email', N'Firstname', N'Lastname', N'PasswordHash', N'PasswordSalt', N'Status', N'UpdatedDate') AND [object_id] = OBJECT_ID(N'[Users]'))
        SET IDENTITY_INSERT [Users] OFF;
END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210121043604_init')
BEGIN
    CREATE INDEX [IX_ApplicationForms_TitleNumberId] ON [ApplicationForms] ([TitleNumberId]);
END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210121043604_init')
BEGIN
    CREATE INDEX [IX_DocumentReferences_RegistrationTypeId] ON [DocumentReferences] ([RegistrationTypeId]);
END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210121043604_init')
BEGIN
    CREATE INDEX [IX_DocumentReferences_UserId] ON [DocumentReferences] ([UserId]);
END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210121043604_init')
BEGIN
    CREATE INDEX [IX_TitleNumbers_DocumentReferenceId] ON [TitleNumbers] ([DocumentReferenceId]);
END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210121043604_init')
BEGIN
    CREATE UNIQUE INDEX [IX_Users_Email] ON [Users] ([Email]) WHERE [Email] IS NOT NULL;
END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210121043604_init')
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20210121043604_init', N'3.1.11');
END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210122044521_ErrorLogs')
BEGIN
    CREATE TABLE [ErrorLogs] (
        [ErrorLogId] bigint NOT NULL IDENTITY,
        [ClassName] nvarchar(500) NULL,
        [Message] nvarchar(max) NULL,
        [Source] nvarchar(max) NULL,
        [StackTraceString] nvarchar(max) NULL,
        [CreatedDate] Datetime NOT NULL DEFAULT (GETDATE()),
        CONSTRAINT [PK_ErrorLogs] PRIMARY KEY ([ErrorLogId])
    );
END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210122044521_ErrorLogs')
BEGIN
    UPDATE [RegistrationTypes] SET [UpdatedDate] = '2021-01-22T10:15:21.1773138+05:30'
    WHERE [RegistrationTypeId] = CAST(1 AS bigint);
    SELECT @@ROWCOUNT;

END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210122044521_ErrorLogs')
BEGIN
    UPDATE [RegistrationTypes] SET [UpdatedDate] = '2021-01-22T10:15:21.1781186+05:30'
    WHERE [RegistrationTypeId] = CAST(2 AS bigint);
    SELECT @@ROWCOUNT;

END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210122044521_ErrorLogs')
BEGIN
    UPDATE [RegistrationTypes] SET [UpdatedDate] = '2021-01-22T10:15:21.1781208+05:30'
    WHERE [RegistrationTypeId] = CAST(3 AS bigint);
    SELECT @@ROWCOUNT;

END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210122044521_ErrorLogs')
BEGIN
    UPDATE [RegistrationTypes] SET [UpdatedDate] = '2021-01-22T10:15:21.1781254+05:30'
    WHERE [RegistrationTypeId] = CAST(4 AS bigint);
    SELECT @@ROWCOUNT;

END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210122044521_ErrorLogs')
BEGIN
    UPDATE [RegistrationTypes] SET [UpdatedDate] = '2021-01-22T10:15:21.1781256+05:30'
    WHERE [RegistrationTypeId] = CAST(5 AS bigint);
    SELECT @@ROWCOUNT;

END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210122044521_ErrorLogs')
BEGIN
    UPDATE [Users] SET [PasswordHash] = 0x011E3699E73C47B88FAFAE84B50F386FE1074ADBA12A7D723D3702B69540D0146734C49997A3839F1076D0FCD8174769E1EF406B175C4CC342B750D194F65551, [PasswordSalt] = 0x484A4BA624E31B127B4C8949BC5E231BB96D0D137AF943E4740BCE4991607A28767198F0E9FCFE701EEDEAE9FCD7B93598830CB9B5DA8B13D01DE3715CAD31AE023A50DAC25FA2E323BF870FAC0DED397C735336228C1853A4B9D224492A5AD9E56E7EDCC074E051A48B868E23A05692357E60240166C01C3EEA36FB6839BCF1
    WHERE [UserId] = CAST(1 AS bigint);
    SELECT @@ROWCOUNT;

END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210122044521_ErrorLogs')
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20210122044521_ErrorLogs', N'3.1.11');
END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210127081142_ignorefield')
BEGIN
    UPDATE [RegistrationTypes] SET [UpdatedDate] = '2021-01-27T13:41:42.2502833+05:30'
    WHERE [RegistrationTypeId] = CAST(1 AS bigint);
    SELECT @@ROWCOUNT;

END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210127081142_ignorefield')
BEGIN
    UPDATE [RegistrationTypes] SET [UpdatedDate] = '2021-01-27T13:41:42.2514708+05:30'
    WHERE [RegistrationTypeId] = CAST(2 AS bigint);
    SELECT @@ROWCOUNT;

END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210127081142_ignorefield')
BEGIN
    UPDATE [RegistrationTypes] SET [UpdatedDate] = '2021-01-27T13:41:42.2514739+05:30'
    WHERE [RegistrationTypeId] = CAST(3 AS bigint);
    SELECT @@ROWCOUNT;

END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210127081142_ignorefield')
BEGIN
    UPDATE [RegistrationTypes] SET [UpdatedDate] = '2021-01-27T13:41:42.2514743+05:30'
    WHERE [RegistrationTypeId] = CAST(4 AS bigint);
    SELECT @@ROWCOUNT;

END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210127081142_ignorefield')
BEGIN
    UPDATE [RegistrationTypes] SET [UpdatedDate] = '2021-01-27T13:41:42.2514745+05:30'
    WHERE [RegistrationTypeId] = CAST(5 AS bigint);
    SELECT @@ROWCOUNT;

END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210127081142_ignorefield')
BEGIN
    UPDATE [Users] SET [PasswordHash] = 0xADFBD506B2A8FE66EE98B66381086C1FC56C2693309A5D41FC367FF391A2CE56B242B4A47DCC9334D357E0E6B2ABA43E8CA2B0585BC76F3CFAB1B47F1D4471C4, [PasswordSalt] = 0xB5A5E30F66A13D53E1E5985934818F9FC83D8FF9BEB9C5B6242C6D7BE5354F5C4E69FA967FDE009784D8C97733A3BCA479E04F3CFD4BD687F04B3AD9CF6DDCBED97F73B61B84D3026EA2E8014A601387E57613062022B0966EF3BBC061149AAC59B1C5F80296954F4402BE61145F9EA22FAADBAF30F75E548D7381B9A5A0E612
    WHERE [UserId] = CAST(1 AS bigint);
    SELECT @@ROWCOUNT;

END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210127081142_ignorefield')
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20210127081142_ignorefield', N'3.1.11');
END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210131155139_fileName')
BEGIN
    ALTER TABLE [ApplicationForms] ADD [FileName] nvarchar(1000) NULL;
END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210131155139_fileName')
BEGIN
    UPDATE [RegistrationTypes] SET [UpdatedDate] = '2021-01-31T21:21:38.9753823+05:30'
    WHERE [RegistrationTypeId] = CAST(1 AS bigint);
    SELECT @@ROWCOUNT;

END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210131155139_fileName')
BEGIN
    UPDATE [RegistrationTypes] SET [UpdatedDate] = '2021-01-31T21:21:38.9764600+05:30'
    WHERE [RegistrationTypeId] = CAST(2 AS bigint);
    SELECT @@ROWCOUNT;

END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210131155139_fileName')
BEGIN
    UPDATE [RegistrationTypes] SET [UpdatedDate] = '2021-01-31T21:21:38.9764624+05:30'
    WHERE [RegistrationTypeId] = CAST(3 AS bigint);
    SELECT @@ROWCOUNT;

END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210131155139_fileName')
BEGIN
    UPDATE [RegistrationTypes] SET [UpdatedDate] = '2021-01-31T21:21:38.9764627+05:30'
    WHERE [RegistrationTypeId] = CAST(4 AS bigint);
    SELECT @@ROWCOUNT;

END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210131155139_fileName')
BEGIN
    UPDATE [RegistrationTypes] SET [UpdatedDate] = '2021-01-31T21:21:38.9764628+05:30'
    WHERE [RegistrationTypeId] = CAST(5 AS bigint);
    SELECT @@ROWCOUNT;

END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210131155139_fileName')
BEGIN
    UPDATE [Users] SET [PasswordHash] = 0x97C4F72EF4C8BD8668848AD4BC8434614914EF8288056276F62ACD9FCCB8650D62552D3BF0AB691EA42EC573B39B9010A65D613955AB9415401B6B21BDE09A12, [PasswordSalt] = 0x67C544F89A6CBB6180F3798896D4156B5B141468813BB4C9D31FD1B0B70FA5D095927816B378D1CA83C537B5B86E163A0345CB4F72395E812279CE0A3EA3B17E459DC1042E92A302FA779E68A882212AC624DBAEB57862EC1CD5858DB7A35B89FB21A099FE27DD3C9B12B65BD47CEBC1380BDE658887CF16B3930184471E3DFC
    WHERE [UserId] = CAST(1 AS bigint);
    SELECT @@ROWCOUNT;

END;

GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20210131155139_fileName')
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20210131155139_fileName', N'3.1.11');
END;

GO

